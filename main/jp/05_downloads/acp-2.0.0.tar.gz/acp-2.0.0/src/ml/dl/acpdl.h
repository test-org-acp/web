/*
 * ACP Middle Layer: Data Library header
 * 
 * Copyright (c) 2014-2014 FUJITSU LIMITED
 * Copyright (c) 2014      Kyushu University
 * Copyright (c) 2014      Institute of Systems, Information Technologies
 *                         and Nanotechnologies 2014
 *
 * This software is released under the BSD License, see LICENSE.
 *
 * Note:
 *
 */
#ifndef __ACPDL_H__
#define __ACPDL_H__

#include "acpdl_malloc.h"

#endif /* acpdl.h */
