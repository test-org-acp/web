/*
 * ACP Middle Layer: Communication Library header
 * 
 * Copyright (c) 2014-2017 Kyushu University
 * Copyright (c) 2014-2017 Institute of Systems, Information Technologies
 *                         and Nanotechnologies 2014
 * Copyright (c) 2014-2017 FUJITSU LIMITED
 *
 * This software is released under the BSD License, see LICENSE.
 *
 * Note:
 *
 */
/** \file progress.h
 * \ingroup acpcl
 */

#ifndef __PROGRESS_H__
#define __PROGRESS_H__

#include <acp.h>

#ifdef __cplusplus
extern "C" {
#endif

void iacpcl_progress(void);


#ifdef __cplusplus
}
#endif


#endif

