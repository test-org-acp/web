#include <stdint.h>
#include <sys/types.h>
#include "acpvd.h"

size_t iacp_starter_memory_size_vd = 1024;

int iacp_init_vd(void)
{
    return 0;
}

int iacp_finalize_vd(void)
{
    return 0;
}

void iacp_abort_vd(void)
{
    return;
}

